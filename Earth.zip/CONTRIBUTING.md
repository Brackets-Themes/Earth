###We recommend the following Brackets extensions to aid in debugging:

*    https://github.com/cfjedimaster/brackets-csslint
*    https://github.com/dsbonev/whitespace-normalizer
*    https://github.com/DennisKehrig/brackets-show-whitespace (optional)
*    https://github.com/couzteau/brackets-git-info (optional)

###Coding Guidelines:

*    Please use 4 spaces instead of tabs.
*    Make sure there is a new line at the end of the file.
*    Install Csslint extension and make sure there are no errors.
